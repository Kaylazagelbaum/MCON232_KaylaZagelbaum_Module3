from blackjack import *

game = BlackjackGame("Joe")
game.play()
