import random
from abc import ABC, abstractmethod

class Card:
    def __init__(self, suit: str, rank: str, value: int):
        self.suit = suit
        self.rank = rank
        self.value = value

    def __str__(self) -> str:
        return f'{self.rank} of {self.suit}'


class Deck(Card):
    def __init__(self, suit="", rank="", value=None) -> None:
        super().__init__(suit, rank, value)
        self.cards = []
        self.cards_left = 52

    def build_deck(self) -> None:
        suits = ["hearts", "diamonds", "clubs", "spades"]
        ranks_and_values = {"Ace": 11, "2": 2, "3": 3, "4": 4, "5": 5, "6": 6, "7": 7, "8": 8, "9": 9, "10": 10, "Jack": 10, "Queen": 10, "King": 10}
        for suit in suits:
            for rank in ranks_and_values.keys():
                self.cards.append(Card(suit, rank, ranks_and_values[rank]))


    def shuffle(self) -> None:
        return random.shuffle(self.cards)


    def deal_card(self) -> Card:
        self.cards_left -= 1
        self.cards_remaining()
        next_card = self.cards.pop()
        return next_card

    def cards_remaining(self) -> int:
        return self.cards_left


class Hand(Card):
    def __init__(self, suit="", rank="", value=None) -> None:
        super().__init__(suit, rank, value)
        self.cards = []

    def add_card(self, card: Card) -> None:
        self.cards.append(card)

    def get_total(self) -> int:
        total = 0
        for card in self.cards:
            total += card.value
        return total

    def show_hand(self) -> None:
        hand = [card.__str__() for card in self.cards]
        print(hand)

    def __str__(self) -> str:
        return f"{self.rank} of {self.suit}"


class Participant(ABC):
    def __init__(self, name: str) -> None:
        self.name = name
        self.hand = Hand()

    def take_card(self, card: Card) -> None:
        self.hand.add_card(card)
        self.determine_ace_value()

    def show_hand(self) -> str:
        return(self.hand.show_hand())

    def get_total(self) -> int:
        total = 0
        for card in self.hand.cards:
            total += card.value
        return total

    def determine_ace_value(self):
        for card in self.hand.cards:
            if card.rank == "Ace":
                if self.get_total() > 21:
                    card.value = 1

    def is_busted(self) -> bool:
        if self.get_total() > 21:
            return True
        else:
            return False

    @abstractmethod
    def take_turn(self, deck: Deck) -> None:
        pass



class Player(Participant):
    def __init__(self, name: str="Player") -> None:
        super().__init__(name)

    def take_turn(self, deck: Deck) -> None:
        self.show_hand()
        while True:
            print("Total", self.get_total())
            hit = input("Do you want to take another card? (y/n) ")
            if hit == "y":
                self.take_card(deck.deal_card())
                self.show_hand()
            if hit == "n":
                break


class Dealer(Participant):
    def __init__(self, name: str="Dealer") -> None:
        super().__init__(name)

    def show_first_card(self, deck: Deck) -> str:
        self.take_card(deck.deal_card())
        return self.show_hand()

    def take_turn(self, deck: Deck) -> None:
        while self.get_total() < 17:
            self.take_card(deck.deal_card())
        # automatically draw cards until total is at least 17


class BlackjackGame:
    def __init__(self, player_name: str) -> None:
        self.deck = Deck()
        self.player = Player(player_name)
        self.dealer = Dealer()


    def initial_deal(self) -> None:
        self.deck.build_deck()
        self.deck.shuffle()
        self.player.take_card(self.deck.deal_card())
        self.player.take_card(self.deck.deal_card())
        print("Dealer's first card:")
        self.dealer.show_first_card(deck=self.deck)

    def show_game_state(self) -> None:
        print("Player:"), self.player.show_hand()
        print("Player Total", self.player.get_total())
        print("Dealer:"), self.dealer.show_hand(),
        print("Dealer Total", self.dealer.get_total())


    def determine_winner(self) -> str:
        player_total = self.player.get_total()
        dealer_total = self.dealer.get_total()
        if player_total > dealer_total:
            print("The player wins")
            return True
        elif player_total == dealer_total:
            print("It's a draw, no one wins")
            return False
        else:
            print("The dealer wins")
            return False

    def play(self) -> None:
        self.initial_deal()

        print("Player's turn:")
        self.player.take_turn(self.deck)
        self.show_game_state()

        if self.player.is_busted():
            print("The player is busted, the dealer wins")
            return True

        print("Dealer's turn:")
        self.dealer.take_turn(self.deck)
        self.show_game_state()
        if self.dealer.is_busted():
            print("The dealer is busted, the player wins")
            return True

        self.determine_winner()







