def binary_search(sorted_nums: list, target: int, low: int, high: int) -> tuple:
    # base case
    if low > high:
        return False

    # recursive case
    mid = (low + high) // 2

    if sorted_nums[mid] == target:
        return mid, sorted_nums[mid]

    elif sorted_nums[mid] > target:
        return binary_search(sorted_nums, target, low, mid -1)

    # I could have written 'else' but I wanted to clearly understand the different return paths
    elif sorted_nums[mid] < target:
        return binary_search(sorted_nums, target, mid+1, high)

print(binary_search([2, 5, 7, 8, 14], 5, 0, 4))