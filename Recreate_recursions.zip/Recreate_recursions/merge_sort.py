def merge_sort(nums: list):
    # base case
    if len(nums) <= 1:
        return nums

    # recursive case
    mid = len(nums) // 2

    left_list = merge_sort(nums[:mid])
    right_list = merge_sort(nums[mid:])

    return merge(left_list, right_list)


def merge(left_list, right_list):
    merged = []

    right_index = 0
    left_index = 0

    while left_index < len(left_list) and right_index < len(right_list):
        if left_list[left_index] < right_list[right_index]:
            merged.append(left_list[left_index])
            left_index += 1
        else:
            merged.append(right_list[right_index])
            right_index += 1

    # add on everything else
    while left_index < len(left_list):
        merged.append(left_list[left_index])
        left_index += 1

    while right_index < len(right_list):
        merged.append(right_list[right_index])
        right_index += 1

    return merged

print(merge_sort([3, 45, 75, 21, 43, 23, 51]))