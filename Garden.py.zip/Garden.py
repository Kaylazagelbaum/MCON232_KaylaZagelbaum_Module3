class Flower:
    def __init__(self, name, petals, color, height):
        self.name = name
        self.petals = petals
        self.color = color
        self.height = height

    def describe(self):
        return f"{self.name} is {self.color}, has {self.petals} petals, and is {self.height} cm tall."

    def grow(self, cm):
        self.height += cm
        return f"{self.name} is now {self.height} cm tall."

# Create flowers
rose = Flower("Rose", 25, "red", 15)
tulip = Flower("Tulip", 10, "purple", 10)
daisy = Flower("Daisy", 8, "yellow", 12)
lily = Flower("Lily", 15, "pink", 7)
garden = [rose, tulip, daisy, lily]

# describe flowers
print("Describe flowers:")
for flower in garden:
    print(flower.describe())

# grow flowers
print("\nGrow flowers:")
for flower in garden:
    print(flower.grow(5))

# reprint information
print("\nUpdated information:")
for flower in garden:
    print(flower.describe())